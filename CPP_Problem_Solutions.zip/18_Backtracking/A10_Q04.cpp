// Problem: Assignment_10_Question_4
// Assignment: 10
// Question: 4
// Domain: 18_Backtracking

#include <iostream>
using namespace std;
int main() {
    int n, graph[20][20];
    bool covered[20][20] = {};
    bool selected[20] = {};
    cout << "Enter number of vertices: ";
    cin >> n;
    if (n < 1 || n > 20) {
        cout << "Invalid number of vertices\n";
        return 0;
    }
    cout << "Enter adjacency matrix:\n";
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cin >> graph[i][j];
        }
    }
    // Select both endpoints of an uncovered edge
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            if (graph[i][j] == 1 && !covered[i][j]) {
                selected[i] = true;
                selected[j] = true;
                // Mark edges incident to either endpoint
                for (int k = 0; k < n; k++) {
                    if (graph[i][k] == 1)
                        covered[i][k] = covered[k][i] = true;
                    if (graph[j][k] == 1)
                        covered[j][k] = covered[k][j] = true;
                }
            }
        }
    }
    int count = 0;
    cout << "Approximate Vertex Cover: ";
    for (int i = 0; i < n; i++) {
        if (selected[i]) {
            cout << i + 1 << " ";
            count++;
        }
    }
    cout << "\nSize of Vertex Cover: " << count << endl;
    return 0;
}
