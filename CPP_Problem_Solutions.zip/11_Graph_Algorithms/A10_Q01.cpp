// Problem: Assignment_10_Question_1
// Assignment: 10
// Question: 1
// Domain: 11_Graph_Algorithms

/* 
Approach:
Create an N * N board filled with ‘.’.
Start placing queens from row 0.
For each column, check whether placing a queen is safe.
If safe, place Q and recursively process the next row.
If all rows are completed, store the board as a solution.
Remove the queen and try the next column (backtracking).
Print all the stored solutions.
*/

#include <iostream>
#include <vector>
#include <string>
using namespace std;
class Solution {
public:
    bool isSafe(vector<string>& board, int row, int col, int n) {
        // Check same row
        for (int j = 0; j < n; j++) {
            if (board[row][j] == 'Q')
                return false;
        }
        // Check same column
        for (int i = 0; i < n; i++) {
            if (board[i][col] == 'Q')
                return false;
        }
        // Check upper-right diagonal
        for (int i = row, j = col;
             i >= 0 && j < n; i--, j++) {
            if (board[i][j] == 'Q')
                return false;
        }
        // Check upper-left diagonal
        for (int i = row, j = col;
             i >= 0 && j >= 0; i--, j--) {
            if (board[i][j] == 'Q')
                return false;
        }
        return true;
    }
    void nQueens(vector<string>& board, int row, int n,
                 vector<vector<string>>& ans) {
        if (row == n) {
            ans.push_back(board);
            return;
        }
        for (int col = 0; col < n; col++) {
            if (isSafe(board, row, col, n)) {
                board[row][col] = 'Q';
                nQueens(board, row + 1, n, ans);
                board[row][col] = '.';
            }
        }
    }
    vector<vector<string>> solveNQueens(int n) {
        vector<string> board(n, string(n, '.'));
        vector<vector<string>> ans;
        nQueens(board, 0, n, ans);
        return ans;
    }
};
int main() {
    int n;
    cout << "Enter N: ";
    cin >> n;
    Solution obj;
    vector<vector<string>> ans = obj.solveNQueens(n);
    int count = 0;
    for (auto board : ans) {
        cout << "\nSolution " << ++count << ":\n";
        for (auto row : board)
            cout << row << endl;
    }
    cout << "\nTotal solutions: " << count << endl;
    return 0;
}
