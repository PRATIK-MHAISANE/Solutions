// Problem: Assignment_9_Question_12
// Assignment: 9
// Question: 12
// Domain: 19_Advanced_Algorithms

/* 
Approach:
enqueue(x): push x onto inStack (actual cost 1).
dequeue(): if outStack is empty, move every item from inStack to outStack (each move costs 1 and reverses the order), then pop and return the top of outStack (cost 1).
Charges: enqueue = 2 units (1 pays for the push, 1 is saved as credit on the item for its future move) and dequeue = 1 unit.
Each item is moved from inStack to outStack at most once, and its saved credit pays for that move, so the credit bank never goes negative.
The program prints the actual cost, the charge and the credit bank after every operation.
Total actual cost <= total amortized cost <= 2n, so n operations cost O(n) even though one dequeue can cost O(n).
*/

#include <bits/stdc++.h>
using namespace std;
 
int main() {
    int n;
    cin >> n;
    vector<int> inStack, outStack;
    long long bank = 0, totalActual = 0, totalAmortized = 0;
 
    cout << left << setw(5) << "No." << setw(16) << "Operation" << setw(8) << "Actual"
         << setw(11) << "Amortized" << setw(13) << "Credit bank" << "Result\n";
 
    for (int i = 1; i <= n; i++) {
        string op;
        cin >> op;
        long long actual = 0, charge = 0;
        string label, result;
 
        if (op == "enqueue") {
            int x;
            cin >> x;
            inStack.push_back(x);
            actual = 1;                    // one push
            charge = 2;                    // 1 for the push, 1 saved for this item's later move
            label = "enqueue(" + to_string(x) + ")";
            result = "-";
        } else {                           // dequeue
            label = "dequeue()";
            if (outStack.empty() && inStack.empty()) {
                result = "queue empty";
            } else {
                if (outStack.empty()) {
                    while (!inStack.empty()) {          // move everything, reversing the order
                        outStack.push_back(inStack.back());
                        inStack.pop_back();
                        actual++;                       // each move = 1 pop + 1 push, counted as 1 unit
                    }
                }
                result = to_string(outStack.back());
                outStack.pop_back();
                actual++;                               // the final pop
                charge = 1;
            }
        }
