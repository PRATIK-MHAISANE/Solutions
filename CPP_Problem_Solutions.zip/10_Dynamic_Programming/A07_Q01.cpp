// Problem: Assignment_7_Question_1
// Assignment: 7
// Question: 1
// Domain: 10_Dynamic_Programming

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
struct Surgery {
    int start;
    int end;
    int priority;
    int id;
};
// Find the last surgery that does not overlap with surgery i
int findPrevious(const vector<Surgery>& surgeries, int i) {
    int low = 0, high = i - 1;
    int answer = -1;
    while (low <= high) {
        int mid = (low + high) / 2;
        if (surgeries[mid].end <= surgeries[i].start) {
            answer = mid;
            low = mid + 1;
        } else {
            high = mid - 1;
        }
    }
    return answer;
}
int main() {
    int n;
    cin >> n;
    vector<Surgery> surgeries(n);
    for (int i = 0; i < n; i++) {
        cin >> surgeries[i].start
            >> surgeries[i].end
            >> surgeries[i].priority;
        surgeries[i].id = i + 1;
    }
    // Sort by ending time
    sort(surgeries.begin(), surgeries.end(),
         [](const Surgery& a, const Surgery& b) {
             return a.end < b.end;
         });
    // dp[i] = maximum priority using first i surgeries
    vector<int> dp(n + 1, 0);
    // previous[i] stores index of last compatible surgery
    vector<int> previous(n);
    for (int i = 0; i < n; i++) {
        previous[i] = findPrevious(surgeries, i);
    }
    // Dynamic Programming
    for (int i = 1; i <= n; i++) {
        // Skip current surgery
        int skip = dp[i - 1];
        // Take current surgery
        int take = surgeries[i - 1].priority;
        int p = previous[i - 1];
        if (p != -1) {
            take += dp[p + 1];
        }
        dp[i] = max(skip, take);
    }
    // Reconstruct selected surgeries
    vector<int> selected;
    int i = n;
    while (i > 0) {
        // If current surgery was selected
        int take = surgeries[i - 1].priority;
        int p = previous[i - 1];
        if (p != -1) {
            take += dp[p + 1];
        }
        if (take > dp[i - 1]) {
            selected.push_back(surgeries[i - 1].id);
            i = p + 1;
        } 
        else {
            i--;
        }
    }
    reverse(selected.begin(), selected.end());
    cout << "Maximum Priority = " << dp[n] << endl;
    cout << "Selected Surgeries: ";
    for (int id : selected) {
        cout << "S" << id << " ";
    }
    cout << endl;
    return 0;
}
