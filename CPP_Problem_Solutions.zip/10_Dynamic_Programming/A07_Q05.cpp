// Problem: Assignment_7_Question_5
// Assignment: 7
// Question: 5
// Domain: 10_Dynamic_Programming

#include <vector>
#include <algorithm>
using namespace std;
struct Job {
    int processing;
    int deadline;
    int penalty;
    int id;
};
int main() {
    int n;
    cin >> n;
    vector<Job> jobs(n);
    int totalPenalty = 0;
    int maxTime = 0;
    for (int i = 0; i < n; i++) {
        cin >> jobs[i].processing
            >> jobs[i].deadline
            >> jobs[i].penalty;
        jobs[i].id = i + 1;
        totalPenalty += jobs[i].penalty;
        maxTime += jobs[i].processing;
    }
    // Sort jobs according to deadline
    sort(jobs.begin(), jobs.end(),
         [](const Job& a, const Job& b) {
             return a.deadline < b.deadline;
         });
    // dp[i][t] = maximum saved penalty
    // using first i jobs with t processing time
    vector<vector<int>> dp(
        n + 1,
        vector<int>(maxTime + 1, 0)
    );
    // Build DP table
    for (int i = 1; i <= n; i++) {
        int p = jobs[i - 1].processing;
        int d = jobs[i - 1].deadline;
        int penalty = jobs[i - 1].penalty;
        for (int t = 0; t <= maxTime; t++) {
            // Don't schedule this job on time
            dp[i][t] = dp[i - 1][t];
            // Schedule this job on time
            if (t >= p && t <= d) {
                dp[i][t] = max(
                    dp[i][t],
                    dp[i - 1][t - p] + penalty
                );
            }
        }
    }
    // Find maximum saved penalty
    int bestSaved = 0;
    int bestTime = 0;
    for (int t = 0; t <= maxTime; t++) {
        if (dp[n][t] > bestSaved) {
            bestSaved = dp[n][t];
            bestTime = t;
        }
    }
    int minimumPenalty = totalPenalty - bestSaved;
    // Reconstruct jobs completed on time
    vector<int> onTime;
    vector<bool> selected(n, false);
    int t = bestTime;
    for (int i = n; i >= 1; i--) {
        if (dp[i][t] == dp[i - 1][t]) {
            continue;
        }
        onTime.push_back(jobs[i - 1].id);
        selected[i - 1] = true;
        t -= jobs[i - 1].processing;
    }
    reverse(onTime.begin(), onTime.end());
    // Add late jobs after on-time jobs
    vector<int> late;
    for (int i = 0; i < n; i++) {
        if (!selected[i]) {
            late.push_back(jobs[i].id);
        }
    }
    cout << "Minimum Penalty = "
         << minimumPenalty << endl;
    cout << "Optimal Job Order: ";
    for (int id : onTime) {
        cout << "J" << id << " ";
    }
    for (int id : late) {
        cout << "J" << id << " ";
    }
    cout << endl;
    return 0;
}
