// Problem: Assignment_7_Question_12
// Assignment: 7
// Question: 12
// Domain: 10_Dynamic_Programming

#include <vector>
#include <climits>
using namespace std;
int main()
{
    int n;
    cin >> n;
    vector<vector<int>> cost(n, vector<int>(n));
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cin >> cost[i][j];
        }
    }
    int hub;
    cin >> hub;
    vector<bool> visited(n, false);
    vector<int> minCost(n, INT_MAX);
    vector<int> parent(n, -1);
    minCost[hub] = 0;
    int totalCost = 0;
    cout << "Cables to be laid:\n";
    for (int count = 0; count < n; count++)
    {
        int u = -1;
        for (int i = 0; i < n; i++)
        {
            if (!visited[i] && (u == -1 || minCost[i] < minCost[u]))
                u = i;
        }
        visited[u] = true;
        if (parent[u] != -1)
        {
            cout << parent[u] << " - " << u
                 << " : " << cost[parent[u]][u] << endl;
            totalCost += cost[parent[u]][u];
        }
        for (int v = 0; v < n; v++)
        {
            if (!visited[v] && cost[u][v] != 0 &&
                cost[u][v] < minCost[v])
            {
                minCost[v] = cost[u][v];
                parent[v] = u;
            }
        }
    }
    cout << "Total minimum cost = " << totalCost << endl;
    return 0;
}
