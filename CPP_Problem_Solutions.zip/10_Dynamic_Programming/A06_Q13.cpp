// Problem: Assignment_6_Question_13
// Assignment: 6
// Question: 13
// Domain: 10_Dynamic_Programming

/* 
Approach:
Create a DP table dp[m+1][n+1]. 
dp[i][j] represents the minimum number of operations required to convert the first i characters of string A into the first j characters of string B. 
Initialize: 
dp[i][0] = i → converting a string to empty requires i deletions. 
dp[0][j] = j → converting empty string to a string requires j insertions. 
For every pair of characters: 
If they are equal:dp[i][j] = dp[i-1][j-1] 
Otherwise, consider: 
Insert: dp[i][j-1] + 1 
Delete: dp[i-1][j] + 1 
Substitute: dp[i-1][j-1] + 1 
Take the minimum. 
The final answer is dp[m][n].
*/

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
int editDistance(string A, string B) {
    int m = A.length();
    int n = B.length();
    // dp[i][j] = minimum operations to convert
    // first i characters of A into first j characters of B
    vector<vector<int>> dp(m + 1, vector<int>(n + 1, 0));
    // Convert A to empty string
    // Requires deletion of all characters
    for (int i = 0; i <= m; i++) {
        dp[i][0] = i;
    }
    // Convert empty string to B
    // Requires insertion of all characters
    for (int j = 0; j <= n; j++) {
        dp[0][j] = j;
    }
    // Fill the DP table
    for (int i = 1; i <= m; i++) {
        for (int j = 1; j <= n; j++) {
            // Characters are already equal
            if (A[i - 1] == B[j - 1]) {
                dp[i][j] = dp[i - 1][j - 1];
            }
            else {
                // Insert a character
                int insert = dp[i][j - 1] + 1;
                // Delete a character
                int deleteOp = dp[i - 1][j] + 1;
                // Substitute a character
                int substitute = dp[i - 1][j - 1] + 1;
                dp[i][j] = min({insert, deleteOp, substitute});
            }
        }
    }
    return dp[m][n];
}
int main() {
    string A, B;
    cout << "Enter mutated DNA sequence: ";
    cin >> A;
    cout << "Enter reference DNA sequence: ";
    cin >> B;
    int answer = editDistance(A, B);
    cout << "Minimum edit distance: " << answer << endl;
    return 0;
}
