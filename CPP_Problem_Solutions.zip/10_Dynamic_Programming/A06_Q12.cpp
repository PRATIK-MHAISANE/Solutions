// Problem: Assignment_6_Question_12
// Assignment: 6
// Question: 12
// Domain: 10_Dynamic_Programming

/* 
Approach:
Create a DP table dp[m+1][n+1]. 
dp[i][j] stores the length of the LCS of: 
first i characters of A 
first j characters of B 
If A[i-1] == B[j-1]: 
The character is part of the LCS. 
dp[i][j] = dp[i-1][j-1] + 1 
Otherwise: 
Either skip the character from A or from B. 
dp[i][j] = max(dp[i-1][j], dp[i][j-1]) 
After filling the table, dp[m][n] is the LCS length. 
To reconstruct the LCS: 
Start from dp[m][n]. 
If characters match, add that character to the answer and move diagonally. 
Otherwise, move toward the larger of the top or left cell. 
Reverse the constructed string.
*/

#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
using namespace std;
int main() {
    string A, B;
    cout << "Enter first sequence: ";
    cin >> A;
    cout << "Enter second sequence: ";
    cin >> B;
    int m = A.length();
    int n = B.length();
    // DP table
    vector<vector<int>> dp(m + 1, vector<int>(n + 1, 0));
    // Build the DP table
    for (int i = 1; i <= m; i++) {
        for (int j = 1; j <= n; j++) {
            if (A[i - 1] == B[j - 1]) {
                // Characters match
                dp[i][j] = dp[i - 1][j - 1] + 1;
            }
            else {
                // Characters don't match
                dp[i][j] = max(dp[i - 1][j],
                               dp[i][j - 1]);
            }
        }
    }
    // Reconstruct LCS
    string lcs = "";
    int i = m;
    int j = n;
    while (i > 0 && j > 0) {
        if (A[i - 1] == B[j - 1]) {
            // This character belongs to LCS
            lcs += A[i - 1];
            i--;
            j--;
        }
        else if (dp[i - 1][j] > dp[i][j - 1]) {
            // Move up
            i--;
        }
        else {
            // Move left
            j--;
        }
    }
    // We constructed it backwards
    reverse(lcs.begin(), lcs.end());
    cout << "Length of LCS: " << dp[m][n] << endl;
    cout << "LCS: " << lcs << endl;
    return 0;
}
