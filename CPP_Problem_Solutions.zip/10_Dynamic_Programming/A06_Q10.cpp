// Problem: Assignment_6_Question_10
// Assignment: 6
// Question: 10
// Domain: 10_Dynamic_Programming

/* 
Approach:
Coin change problem using Dynamic Programming to find the minimum number of coins.
*/

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int minCoins(vector<int>& coins, int target) {
    vector<int> dp(target + 1, target + 1);
    dp[0] = 0;
    for (int amount = 1; amount <= target; amount++) {
        for (int coin : coins) {
            if (coin <= amount) {
                dp[amount] = min(dp[amount], dp[amount - coin] + 1);
            }
        }
    }
    return dp[target] > target ? -1 : dp[target];
}

int main() {
    int n, target;
    cout << "Enter number of coin denominations: ";
    if (!(cin >> n)) return 0;
    vector<int> coins(n);
    cout << "Enter coin denominations:
";
    for (int i = 0; i < n; i++) cin >> coins[i];
    cout << "Enter target amount: ";
    cin >> target;
    int result = minCoins(coins, target);
    cout << "Minimum coins required: " << result << endl;
    return 0;
}
