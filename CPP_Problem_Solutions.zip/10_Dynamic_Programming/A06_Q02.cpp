// Problem: Assignment_6_Question_2
// Assignment: 6
// Question: 2
// Domain: 10_Dynamic_Programming

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
int knapsack(vector<int>& weight, vector<int>& value, int n, int W) {
    // dp[i][w] = maximum value using first i items
    // with capacity w
    vector<vector<int>> dp(n + 1, vector<int>(W + 1, 0));
    for (int i = 1; i <= n; i++) {
        for (int w = 1; w <= W; w++) {
            // If current item is too heavy
            if (weight[i - 1] > w) {
                dp[i][w] = dp[i - 1][w];
            }
            else {
                // Option 1: Don't take the item
                int notTake = dp[i - 1][w];
                // Option 2: Take the item
                int take = value[i - 1] +
                           dp[i - 1][w - weight[i - 1]];
                dp[i][w] = max(take, notTake);
            }
        }
    }
    return dp[n][W];
}
int main() {
    int n, W;
    cout << "Enter number of items: ";
    cin >> n;
    cout << "Enter capacity: ";
    cin >> W;
    vector<int> weight(n);
    vector<int> value(n);
    cout << "Enter weight and value of each item:\n";
    for (int i = 0; i < n; i++) {
        cin >> weight[i] >> value[i];
    }
    int answer = knapsack(weight, value, n, W);
    cout << "Maximum achievable value: " << answer << endl;
    return 0;
}
