// Problem: Lost Package Tracker
// Assignment: 2
// Question: 5
// Domain: 09_Binary_Search

/* Problem Statement:
Find the first missing timestamp in a sorted array containing repeated values.

Approach:
Erase duplicates, then binary search for the first index where t[i] - t[0] > i.
*/

#include <bits/stdc++.h>
using namespace std;
int main() {
    int n;
    cin >> n;
    vector<int> t(n);
    for (int i = 0; i < n; i++) cin >> t[i];
    t.erase(unique(t.begin(), t.end()), t.end());
    int m = t.size();
    int lo = 0, hi = m;
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        if (t[mid] - t[0] > mid) hi = mid;
        else lo = mid + 1;
    }
    if (lo == m) cout << "No timestamp is missing in the range\n";
    else cout << "First missing timestamp = " << t[0] + lo << '\n';
    return 0;
}

/* Sample Input & Output:
Input: 4
1001 1002 1004 1005
Output: First missing timestamp = 1003
*/

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra A02_Q05_Lost_Package_Tracker.cpp -o A02_Q05_Lost_Package_Tracker.exe && .\A02_Q05_Lost_Package_Tracker.exe
