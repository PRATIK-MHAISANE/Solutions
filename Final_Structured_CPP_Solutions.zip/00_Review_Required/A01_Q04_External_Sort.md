# Problem: Sorting a 20GB File (External Sort)
## Assignment 1, Question 4

**Problem Statement:**
Imagine you have a 20GB file with one string per line. Explain how you would sort the file.

**Approach:**
External Merge Sort (Phase 1: Divide and sort in chunks, Phase 2: K-way merge using a min-heap).

*Note: Flagged for review because only algorithmic explanation was provided, no C++ code.*