# Index
Lists all processed questions mapped to their domain.