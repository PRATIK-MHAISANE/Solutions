// Problem: Shared Office Printer SJF
// Assignment: 5
// Question: 4
// Domain: 08_Greedy_Algorithms

/* Problem Statement:
Minimize the total waiting time for print jobs.

Approach:
Shortest-Job-First (SJF). Sort jobs in ascending order.
*/

#include <bits/stdc++.h>
using namespace std;
int main() {
    vector<int> jobs = {45,120,30,80,200,10,150,70};
    sort(jobs.begin(), jobs.end());
    long long waitingTime = 0, totalWait = 0;
    for (int t : jobs) {
        totalWait += waitingTime;
        waitingTime += t;
    }
    cout << "Total waiting time: " << totalWait << endl;
    return 0;
}

/* Sample Input & Output:
Data hardcoded.
*/

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra A05_Q04_Shared_Printer.cpp -o A05_Q04_Shared_Printer.exe && .\A05_Q04_Shared_Printer.exe
