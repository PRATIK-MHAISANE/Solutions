# Document Inventory
- Assignments 1 to 5: PROCESSED
- Assignments 6 to 10: PROCESSED