// Problem: Tiling Problem (L-shaped tiles)
// Assignment: 3
// Question: 2
// Domain: 05_Functions_Recursion

/* Problem Statement:
An n x n board has one missing cell. Fill the rest with L-shaped tiles.

Approach:
Divide the board into four n/2 quadrants. Place one central L-tile covering the three non-missing quadrants, then recurse.
*/

#include <bits/stdc++.h>
using namespace std;
int board[64][64];
int tileNo = 0;
void tile(int r0, int c0, int mr, int mc, int size) {
    if (size == 1) return;
    int id = ++tileNo;
    int half = size / 2;
    int cr = r0 + half, cc = c0 + half;
    bool top  = mr < cr;
    bool left = mc < cc;
    if (top && left) tile(r0, c0, mr, mc, half);
    else { board[cr - 1][cc - 1] = id; tile(r0, c0, cr - 1, cc - 1, half); }
    if (top && !left) tile(r0, cc, mr, mc, half);
    else { board[cr - 1][cc] = id; tile(r0, cc, cr - 1, cc, half); }
    if (!top && left) tile(cr, c0, mr, mc, half);
    else { board[cr][cc - 1] = id; tile(cr, c0, cr, cc - 1, half); }
    if (!top && !left) tile(cr, cc, mr, mc, half);
    else { board[cr][cc] = id; tile(cr, cc, cr, cc, half); }
}
int main() {
    int n, r, c;
    cin >> n >> r >> c;
    board[r][c] = 0;
    tile(0, 0, r, c, n);
    cout << "Tiles used = " << tileNo << '\n';
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (i == r && j == c) cout << setw(4) << "X";
            else cout << setw(4) << board[i][j];
        }
        cout << '\n';
    }
    return 0;
}

/* Sample Input & Output:
Input: 2 0 1
Output: Tiles used = 1
*/

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra A03_Q02_Tiling_Problem.cpp -o A03_Q02_Tiling_Problem.exe && .\A03_Q02_Tiling_Problem.exe
