// Problem: Candy in the K-th Box
// Assignment: 2
// Question: 2
// Domain: 17_Mathematics_Number_Theory

/* Problem Statement:
N boxes and K candies are filled in an oscillating order. Find the index of the box that receives the K-th candy.

Approach:
Compute position inside the cycle: p = (K - 1) mod 2(N-1). Find box logically moving right or left.
*/

#include <bits/stdc++.h>
using namespace std;
int main() {
    long long N, K;
    cin >> N >> K;
    long long box;
    if (N == 1) {
        box = 1;
    } else {
        long long period = 2 * (N - 1);
        long long p = (K - 1) % period;
        if (p <= N - 1) box = p + 1;
        else box = period - p + 1;
    }
    cout << "Candy " << K << " goes into box " << box << '\n';
    return 0;
}

/* Sample Input & Output:
Input: 5 8
Output: Candy 8 goes into box 2
*/

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra A02_Q02_Candy_Kth_Box.cpp -o A02_Q02_Candy_Kth_Box.exe && .\A02_Q02_Candy_Kth_Box.exe
