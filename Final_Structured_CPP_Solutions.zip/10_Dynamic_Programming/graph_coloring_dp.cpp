// Problem: Graph Coloring DP/Bitmask
// Original file: A07_Q07.cpp

/* Problem Statement:
Graph Coloring DP/Bitmask

Approach:
Use DP with bitmask to find minimum colors for a graph.
*/

#include <bits/stdc++.h>
using namespace std;
const int INF = 1e9;
int n, m;
vector<vector<int>> conflict;
vector<int> difficulty;
// ---------- PART 1: GRAPH COLORING ----------
bool isSafe(int exam, int color, vector<int>& colors) {
    for (int other = 0; other < n; other++) {
        if (conflict[exam][other] && colors[other] == color)
            return false;
    }
    return true;
}
bool colorGraph(int exam, int totalSlots, vector<int>& colors) {
    if (exam == n)
        return true;
    for (int color = 0; color < totalSlots; color++) {
        if (isSafe(exam, color, colors)) {
            colors[exam] = color;
            if (colorGraph(exam + 1, totalSlots, colors))
                return true;
            colors[exam] = -1;
        }
    }
    return false;
}
int findMinimumSlots(vector<int>& bestColor) {
    for (int slots = 1; slots <= n; slots++) {
        vector<int> colors(n, -1);
        if (colorGraph(0, slots, colors)) {
            bestColor = colors;
            return slots;
        }
    }
    return n;
}
// ---------- PART 2: BITMASK DP ----------
// Check whether all exams in mask can be placed
// in the same time slot.
bool validMask(int mask) {
    for (int i = 0; i < n; i++) {
        if (!(mask & (1 << i)))
            continue;
        for (int j = i + 1; j < n; j++) {
            if ((mask & (1 << j)) && conflict[i][j])
                return false;
        }
    }
    return true;
}
// Penalty between two consecutive slots.
// Penalty = 1 for every conflicting pair of
// high-difficulty exams in adjacent slots.
int getPenalty(int mask1, int mask2) {
    int penalty = 0;
    for (int i = 0; i < n; i++) {
        if (!(mask1 & (1 << i)))
            continue;
        // High difficulty exam
        if (difficulty[i] < 7)
            continue;
        for (int j = 0; j < n; j++) {
            if (!(mask2 & (1 << j)))
                continue;
            if (difficulty[j] < 7)
                continue;
            if (conflict[i][j])
                penalty++;
        }
    }
    return penalty;
}
// DP state:
// used       = exams already scheduled
// lastMask   = exams in previous slot
// slotsLeft  = number of slots still available
//
// Returns minimum penalty.
map<tuple<int, int, int>, int> memo;
map<tuple<int, int, int>, int> choice;
int solveDP(int used, int lastMask, int slotsLeft) {
    // All exams scheduled
    if (used == (1 << n) - 1) {
        return (slotsLeft == 0) ? 0 : INF;
    }
    // No slots remaining but exams are still left
    if (slotsLeft == 0)
        return INF;
    auto state = make_tuple(used, lastMask, slotsLeft);
    if (memo.count(state))
        return memo[state];
    int remaining = ((1 << n) - 1) ^ used;
    int answer = INF;
    int bestMask = -1;
    // Try every non-empty subset of remaining exams
    for (int sub = remaining; sub > 0; sub = (sub - 1) & remaining) {
        // The exams in this slot must not conflict
        if (!validMask(sub))
            continue;
        // If this is the last slot, it must contain
        // all remaining exams.
        if (slotsLeft == 1 && sub != remaining)
            continue;
        int currentPenalty = 0;
        if (lastMask != 0)
            currentPenalty = getPenalty(lastMask, sub);
        int next = solveDP(
            used | sub,
            sub,
            slotsLeft - 1
        );
        if (next != INF &&
            currentPenalty + next < answer) {
            answer = currentPenalty + next;
            bestMask = sub;
        }
    }
    choice[state] = bestMask;
    return memo[state] = answer;
}
// Print exams present in a mask
void printMask(int mask) {
    for (int i = 0; i < n; i++) {
        if (mask & (1 << i))
            cout << "Exam " << i + 1 << " ";
    }
    cout << endl;
}
int main() {
    cout << "Enter number of exams: ";
    cin >> n;
    cout << "Enter number of conflict pairs: ";
    cin >> m;
    conflict.assign(n, vector<int>(n, 0));
    cout << "Enter conflict pairs (exam numbers 1 to "
         << n << "):\n";
    for (int i = 0; i < m; i++) {
        int u, v;
        cin >> u >> v;
        u--;
        v--;
        conflict[u][v] = 1;
        conflict[v][u] = 1;
    }
    difficulty.resize(n);
    cout << "Enter difficulty of each exam:\n";
    for (int i = 0; i < n; i++)
        cin >> difficulty[i];
    // =========================
    // PART 1
    // =========================
    vector<int> coloring;
    int minimumSlots = findMinimumSlots(coloring);
    cout << "\n========== PART 1 ==========\n";
    cout << "Minimum number of slots = "
         << minimumSlots << endl;
    cout << "One valid slot assignment:\n";
    for (int i = 0; i < n; i++) {
        cout << "Exam " << i + 1
             << " -> Slot " << coloring[i] + 1
             << endl;
    }
    // =========================
    // PART 2
    // =========================
    cout << "\n========== PART 2 ==========\n";
    memo.clear();
    choice.clear();
    int minimumPenalty = solveDP(
        0,
        0,
        minimumSlots
    );
    cout << "Minimum difficulty penalty = "
         << minimumPenalty << endl;
    // Reconstruct answer
    vector<int> finalSlot(n, -1);
    int used = 0;
    int lastMask = 0;
    int slotsLeft = minimumSlots;
    int slotNumber = 1;
    while (used != (1 << n) - 1) {
        auto state =
            make_tuple(used, lastMask, slotsLeft);
        int selectedMask = choice[state];
        if (selectedMask == -1)
            break;
        for (int i = 0; i < n; i++) {
            if (selectedMask & (1 << i))
                finalSlot[i] = slotNumber;
        }
        used |= selectedMask;
        lastMask = selectedMask;
        slotsLeft--;
        slotNumber++;
    }
    cout << "\nFinal exam schedule:\n";
    for (int s = 1; s <= minimumSlots; s++) {
        cout << "Slot " << s << ": ";
        for (int i = 0; i < n; i++) {
            if (finalSlot[i] == s)
                cout << "Exam " << i + 1 << " ";
        }
        cout << endl;
    }
    return 0;
}

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra graph_coloring_dp.cpp -o graph_coloring_dp.exe && .\graph_coloring_dp.exe
