// Problem: Minimum Coin Change
// Original file: A06_Q03.cpp

/* Problem Statement:
Minimum Coin Change

Approach:
Use DP to find minimum coins required to make amount.
*/

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
// Part A: Minimum number of coins
int minCoins(vector<int>& coins, int target) {
    // dp[i] = minimum coins required to make amount i
    vector<int> dp(target + 1, target + 1);
    // 0 coins are needed to make amount 0
    dp[0] = 0;
    for (int amount = 1; amount <= target; amount++) {
        for (int coin : coins) {
            if (coin <= amount) {
                dp[amount] = min(
                    dp[amount],
                    dp[amount - coin] + 1
                );
            }
        }
    }
    // If target cannot be formed
    if (dp[target] == target + 1)
        return -1;
    return dp[target];
}
// Part B: Number of distinct combinations
int countWays(vector<int>& coins, int target) {
    // ways[i] = number of combinations to make amount i
    vector<int> ways(target + 1, 0);
    // One way to make 0: choose nothing
    ways[0] = 1;
    for (int coin : coins) {
        // Start from coin so that amount-coin is valid
        for (int amount = coin; amount <= target; amount++) {
            ways[amount] += ways[amount - coin];
        }
    }
    return ways[target];
}
int main() {
    int n, target;
    cout << "Enter number of denominations: ";
    cin >> n;
    vector<int> coins(n);
    cout << "Enter denominations: ";
    for (int i = 0; i < n; i++) {
        cin >> coins[i];
    }
    cout << "Enter target amount: ";
    cin >> target;
    // Part A
    int minimum = minCoins(coins, target);
    // Part B
    int ways = countWays(coins, target);
    cout << "Minimum number of coins: " << minimum << endl;
    cout << "Number of distinct ways: " << ways << endl;
    return 0;
}

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra minimum_coin_change_v2.cpp -o minimum_coin_change_v2.exe && .\minimum_coin_change_v2.exe
