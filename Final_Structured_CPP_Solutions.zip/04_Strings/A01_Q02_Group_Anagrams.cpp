// Problem: Group Anagrams Together
// Assignment: 1
// Question: 2
// Domain: 04_Strings

/* Problem Statement:
Write a method to sort an array of strings so that all the anagrams are next to each other.

Approach:
Compute a 'signature' for each string by sorting its characters, and then group strings using this signature.
*/

#include <bits/stdc++.h>
using namespace std;
void groupAnagrams(vector<string>& words) {
    sort(words.begin(), words.end(), [](const string& a, const string& b) {
        string ka = a, kb = b;
        sort(ka.begin(), ka.end());
        sort(kb.begin(), kb.end());
        return ka < kb;
    });
}
vector<string> groupAnagramsHashMap(vector<string>& words) {
    unordered_map<string, vector<string>> groups;
    for (auto& w : words) {
        string key = w;
        sort(key.begin(), key.end());
        groups[key].push_back(w);
    }
    vector<string> result;
    for (auto& [key, group] : groups)
        for (auto& w : group) result.push_back(w);
    return result;
}

/* Sample Input & Output:
No sample I/O provided in the source document.
*/

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra A01_Q02_Group_Anagrams.cpp -o A01_Q02_Group_Anagrams.exe && .\A01_Q02_Group_Anagrams.exe
