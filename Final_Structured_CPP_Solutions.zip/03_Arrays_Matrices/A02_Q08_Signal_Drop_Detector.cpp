// Problem: Signal Drop Detector
// Assignment: 2
// Question: 8
// Domain: 03_Arrays_Matrices

/* Problem Statement:
Count the number of strictly decreasing runs of at least 3 consecutive readings.

Approach:
Extend runs sequentially, count any decreasing run of length >= 3 once, and jump to j+1.
*/

#include <bits/stdc++.h>
using namespace std;
int main() {
    int n;
    cin >> n;
    vector<int> signal(n);
    for (int i = 0; i < n; i++) cin >> signal[i];
    int drops = 0;
    int i = 0;
    while (i < n) {
        int j = i;
        while (j + 1 < n && signal[j] > signal[j + 1]) j++;
        int length = j - i + 1;
        if (length >= 3) {
            drops++;
            cout << "Drop: ";
            for (int k = i; k <= j; k++) {
                cout << signal[k];
                if (k < j) cout << " -> ";
            }
            cout << '\n';
        }
        i = j + 1;
    }
    cout << "Number of signal drops = " << drops << '\n';
    return 0;
}

/* Sample Input & Output:
Input: 8
5 4 3 6 7 4 3 2
Output: Number of signal drops = 2
*/

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra A02_Q08_Signal_Drop_Detector.cpp -o A02_Q08_Signal_Drop_Detector.exe && .\A02_Q08_Signal_Drop_Detector.exe
