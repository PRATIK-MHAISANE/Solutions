// Problem: Dynamic Table Contraction
// Original file: A09_Q09.cpp

/* Problem Statement:
Dynamic Table Contraction

Approach:
Amortized analysis of dynamic table contraction policy.
*/

#include <bits/stdc++.h>
using namespace std;
 
// Cost model (explained in the report):
//   insert : 1 unit to store the element, plus (items copied) if the table is full and doubles
//   delete : 1 unit to remove the element, plus (items copied + 1 to free the old block)
//            if the table contracts
struct Table {
    int size, items;
    double contractAt;                 // contract when load factor <= contractAt
    long long total = 0, resizes = 0;
 
    // returns the cost of the operation
    long long insert() {
        long long cost = 0;
        if (items == size) {           // table full: expand to twice the size
            cost += items;             // copy all items into the new table
            size *= 2;
            resizes++;
        }
        cost += 1;
        items++;
        total += cost;
        return cost;
    }
    long long erase() {
        long long cost = 1;
        items--;
        if (size > 1 && items <= contractAt * size) {   // too empty: halve the table
            cost += items + 1;         // copy what is left, +1 to free the old block
            size /= 2;
            resizes++;
        }
        total += cost;
        return cost;
    }
};
 
int main() {
    int size, items, ops;
    string first;
    cin >> size >> items >> ops >> first;     // first = "delete" or "insert"
 
    Table A{size, items, 0.5};                // Policy A: naive, contract at 1/2 full
    Table B{size, items, 0.25};               // Policy B: safe,  contract at 1/4 full
 
    cout << "Start: table size " << size << ", " << items << " items, " << ops
         << " operations alternating delete/insert (first = " << first << ")\n\n";
    cout << left << setw(5) << "Op" << setw(9) << "Type" << "| Policy A: cost  size  items | Policy B: cost  size  items\n";
 
    bool doDelete = (first == "delete");
    for (int i = 1; i <= ops; i++) {
        long long ca, cb;
        if (doDelete) { ca = A.erase(); cb = B.erase(); }
        else          { ca = A.insert(); cb = B.insert(); }
        cout << left << setw(5) << i << setw(9) << (doDelete ? "DELETE" : "INSERT")
             << "|            " << right << setw(4) << ca << setw(6) << A.size << setw(7) << A.items
             << " |            " << setw(4) << cb << setw(6) << B.size << setw(7) << B.items << '\n';
        doDelete = !doDelete;
    }
 
    cout << fixed << setprecision(2);
    cout << "\n" << left << setw(36) << "Policy" << setw(20) << ("Total Cost (" + to_string(ops) + " ops)")
         << setw(27) << "Average Cost / Operation" << "Resizes\n";
    cout << setw(36) << "A - naive (contract at 1/2 full)" << setw(20) << A.total
         << setw(27) << (double)A.total / ops << A.resizes << '\n';
    cout << setw(36) << "B - safe (contract at 1/4 full)" << setw(20) << B.total
         << setw(27) << (double)B.total / ops << B.resizes << '\n';
    return 0;
}

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra dynamic_table_contraction.cpp -o dynamic_table_contraction.exe && .\dynamic_table_contraction.exe
