// Problem: Strassen's Matrix Multiplication
// Assignment: 3
// Question: 5
// Domain: 19_Advanced_Algorithms

/* Problem Statement:
Multiply two n x n matrices using Strassen's algorithm in O(n^2.81) time.

Approach:
Divide into 4 quadrants, compute 7 products recursively, combine them.
*/

#include <bits/stdc++.h>
using namespace std;
typedef vector<vector<long long>> Matrix;
long long multiplications = 0;
Matrix add(const Matrix& A, const Matrix& B) {
    int n = A.size();
    Matrix C(n, vector<long long>(n));
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++) C[i][j] = A[i][j] + B[i][j];
    return C;
}
Matrix sub(const Matrix& A, const Matrix& B) {
    int n = A.size();
    Matrix C(n, vector<long long>(n));
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++) C[i][j] = A[i][j] - B[i][j];
    return C;
}
Matrix block(const Matrix& M, int r, int c, int h) {
    Matrix R(h, vector<long long>(h));
    for (int i = 0; i < h; i++)
        for (int j = 0; j < h; j++) R[i][j] = M[r + i][c + j];
    return R;
}
Matrix strassen(const Matrix& A, const Matrix& B) {
    int n = A.size();
    if (n == 1) { multiplications++; return {{A[0][0] * B[0][0]}}; }
    int h = n / 2;
    Matrix A11 = block(A, 0, 0, h), A12 = block(A, 0, h, h);
    Matrix A21 = block(A, h, 0, h), A22 = block(A, h, h, h);
    Matrix B11 = block(B, 0, 0, h), B12 = block(B, 0, h, h);
    Matrix B21 = block(B, h, 0, h), B22 = block(B, h, h, h);
    Matrix M1 = strassen(add(A11, A22), add(B11, B22));
    Matrix M2 = strassen(add(A21, A22), B11);
    Matrix M3 = strassen(A11, sub(B12, B22));
    Matrix M4 = strassen(A22, sub(B21, B11));
    Matrix M5 = strassen(add(A11, A12), B22);
    Matrix M6 = strassen(sub(A21, A11), add(B11, B12));
    Matrix M7 = strassen(sub(A12, A22), add(B21, B22));
    Matrix C11 = add(sub(add(M1, M4), M5), M7);
    Matrix C12 = add(M3, M5);
    Matrix C21 = add(M2, M4);
    Matrix C22 = add(sub(add(M1, M3), M2), M6);
    Matrix C(n, vector<long long>(n));
    for (int i = 0; i < h; i++)
        for (int j = 0; j < h; j++) {
            C[i][j]         = C11[i][j];
            C[i][j + h]     = C12[i][j];
            C[i + h][j]     = C21[i][j];
            C[i + h][j + h] = C22[i][j];
        }
    return C;
}
int main() {
    int n;
    cin >> n;
    Matrix A(n, vector<long long>(n)), B(n, vector<long long>(n));
    for (auto& row : A) for (auto& v : row) cin >> v;
    for (auto& row : B) for (auto& v : row) cin >> v;
    Matrix C = strassen(A, B);
    for (auto& row : C) {
        for (long long v : row) cout << setw(8) << v;
        cout << '\n';
    }
    return 0;
}

/* Sample Input & Output:
Input: 2 (followed by 4 A elements and 4 B elements)
*/

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra A03_Q05_Strassens_Matrix_Multiplication.cpp -o A03_Q05_Strassens_Matrix_Multiplication.exe && .\A03_Q05_Strassens_Matrix_Multiplication.exe
