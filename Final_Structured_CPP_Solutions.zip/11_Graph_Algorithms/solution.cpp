// Problem: Algorithm Problem
// Original file: A08_Q01.cpp

/* Problem Statement:
Algorithm Problem

Approach:
Algorithm implementation.
*/

#include <bits/stdc++.h>
using namespace std;
struct Road {
    int to, w, id;
};
int main() {
    int N;
    cin >> N;
    vector<int> S(N), T(N), D(N);
    int maxTown = 0;
    for (int i = 0; i < N; i++) {
        cin >> S[i] >> T[i] >> D[i];
        maxTown = max(maxTown, max(S[i], T[i]));
    }
    // Build adjacency list for undirected roads
    vector<vector<Road>> adj(maxTown + 1);
    for (int i = 0; i < N; i++) {
        adj[S[i]].push_back({T[i], D[i], i});
        if (S[i] != T[i]) {
            adj[T[i]].push_back({S[i], D[i], i});
        }
    }
    const long long INF = LLONG_MAX / 4;
    long long answer = INF;
    for (int removed = 0; removed < N; removed++) {
        int src = S[removed];
        int dst = T[removed];
        // Handle a road from a town to itself
        if (src == dst) {
            answer = min(answer, (long long)D[removed]);
            continue;
        }
        // Dijkstra's algorithm, excluding the selected road
        vector<long long> dist(maxTown + 1, INF);
        priority_queue<
            pair<long long, int>,
            vector<pair<long long, int>>,
            greater<pair<long long, int>>
        > pq;
        dist[src] = 0;
        pq.push({0, src});
        while (!pq.empty()) {
            long long d = pq.top().first;
            int u = pq.top().second;
            pq.pop();
            if (d > dist[u]) continue;
            if (u == dst) break;
            if (d + D[removed] >= answer) break;
            for (const Road& r : adj[u]) {
                if (r.id == removed) continue;
                if (d + r.w < dist[r.to]) {
                    dist[r.to] = d + r.w;
                    pq.push({dist[r.to], r.to});
                }
            }
        }
        // Combine the alternative path with the removed road
        if (dist[dst] < INF) {
            answer = min(answer, dist[dst] + D[removed]);
        }
    }
    if (answer == INF) {
        cout << -1 << '\n';
    } else {
        cout << answer << '\n';
    }
    return 0;
}

// Compile and run (VS Code Terminal - CMD/PowerShell):
// g++ -std=c++17 -O2 -Wall -Wextra solution.cpp -o solution.exe && .\solution.exe
